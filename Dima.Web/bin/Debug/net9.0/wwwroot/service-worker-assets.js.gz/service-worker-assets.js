self.assetsManifest = {
  "version": "vbn7HKF8",
  "assets": [
    {
      "hash": "sha256-rn8eNl+9uB529WfApYjM5fW3PddfCejXYcvfIgZsvkk=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-tDzFduRg9GB+l7v4qTqHjA9DWw0gYW4sJ+rNyuAbrAQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Wp9CSOsl26za6JT9e0wHif3sjR96KP/4G7pzvS6tzfQ=",
      "url": "_framework/Dima.Web.eilfafanc2.wasm"
    },
    {
      "hash": "sha256-0gZXCWtSqG9NMLgNjTA7ifho0XO+Qs7xQruB0J1tDJI=",
      "url": "_framework/Dima.Web.qmyqxtg63m.pdb"
    },
    {
      "hash": "sha256-wop7u1vkqMrC8STyHNjo8fU4gzcpIHVH4Dy+31RvXV8=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.6iz29fp231.wasm"
    },
    {
      "hash": "sha256-5Kvi+T18AEE82xuKJy5gaVG+FzhEGB87tQ6Bbi417Jk=",
      "url": "_framework/Microsoft.AspNetCore.Components.8n2ag8dq2h.wasm"
    },
    {
      "hash": "sha256-YvxQDzl9jTMybx9LIkYzqslgkEFU0oXzWhX4NoIURBw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.e1f5dhd1hi.wasm"
    },
    {
      "hash": "sha256-oHwM+Z+HScjwUMYDYGsf4zreIh62VcnzCAJ07XDM/14=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.86ocmak03v.wasm"
    },
    {
      "hash": "sha256-y5EoUwe+vwUyqY9vTCBHGruvyTo9hL5pbhQIC/goWlU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nd2r1nfwds.wasm"
    },
    {
      "hash": "sha256-YdR8Enq4RTCMFRglAwfN1MDDlu5ICZJEIXpvPPj62ls=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.v8mg78pdpt.wasm"
    },
    {
      "hash": "sha256-WUxYs8R+02g5obsTCaR44+E2iLlS3sZaSJgtGqidq9g=",
      "url": "_framework/Microsoft.CSharp.16wq3dn6m6.wasm"
    },
    {
      "hash": "sha256-wE4Y85aqW/nJrpIaI026z5mTm8Lk5bG63TDBfK4rSC0=",
      "url": "_framework/Microsoft.Extensions.Configuration.4rvupb7m1y.wasm"
    },
    {
      "hash": "sha256-5NEpMcFWmf1zOT9gVto9dLc9JQR0+iSX36XkwTIaQn0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s2ocphnvrv.wasm"
    },
    {
      "hash": "sha256-8ht+kDkM2oju65zgoRGb82Er0f9fbCsSnC9hoMwtjp8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.yjk8mt644v.wasm"
    },
    {
      "hash": "sha256-dyzIjZLFjd/q1okMX0X67oukbEs+hfn6flJuIZAr8aQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.tbalgzftfn.wasm"
    },
    {
      "hash": "sha256-c6uOhbcQQKcKFfor1b1wkvxgpumigsyLkFYtWtlvcBY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.zcm57tr0o5.wasm"
    },
    {
      "hash": "sha256-JKIKLwj/AKnnp6K6MFV1DVvWH70RHMjG3hg9gXLR/kY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.4uq025m44x.wasm"
    },
    {
      "hash": "sha256-DNazNV8ygiVVrS8i/F4iPitOEz+1q10QjEm9nyOnEas=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.odqaelrd2d.wasm"
    },
    {
      "hash": "sha256-cTHv50E/+XRKUIn5Wu8Ns7CWFhfagvB8Wxc+cPKnRYc=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.5vt9i0est7.wasm"
    },
    {
      "hash": "sha256-dqPb1KgDulx21tuzwSSXNIofZ0hRCKv3QiPbaaUa+Zo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.y13gsdo7nh.wasm"
    },
    {
      "hash": "sha256-Jip5pPogxp1kLPSZwiD9Gr1lOWAwoczBnGo/izzfhSI=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.ydnrzy3ypg.wasm"
    },
    {
      "hash": "sha256-N6ZBgmVtKuTLyVca1QduGSfIrtLeu8VDZTMjHhRoW0Q=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.xe3ex8nc4u.wasm"
    },
    {
      "hash": "sha256-csBUd4QuytZ4vFjfWtJaYptncxX/miKR5lPhAB9gefg=",
      "url": "_framework/Microsoft.Extensions.Localization.qab9fk66hy.wasm"
    },
    {
      "hash": "sha256-zjrN1pShJJ4EC/yQAVCq/Y1PGJcSw8YjX9Dv4WrWSwE=",
      "url": "_framework/Microsoft.Extensions.Logging.2je9trs1wb.wasm"
    },
    {
      "hash": "sha256-o7fo9h2MRr1LWQ/JtFYkuQ+Dwsd8N1qwpkEfJtSEpJo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.j0l56ybynk.wasm"
    },
    {
      "hash": "sha256-fuOr/5Cok4mATS8X8d2oZAT5KQlXNNK4P/QP4GSBQis=",
      "url": "_framework/Microsoft.Extensions.Options.m7rnnjp4uf.wasm"
    },
    {
      "hash": "sha256-1XyFPijIIoAkvZfbi3y1vfKFdAxYKv5MvBE4QDZBpcU=",
      "url": "_framework/Microsoft.Extensions.Primitives.1ptej74xfe.wasm"
    },
    {
      "hash": "sha256-v2YM90AAOAn8FVvguS+ty3dyqggCNRDvpcZf7C8zACE=",
      "url": "_framework/Microsoft.JSInterop.10ovy7r2cv.wasm"
    },
    {
      "hash": "sha256-tfBp5jj3ogHoMRNBZdLDdQ9xbonK7V4sxCClroBB7qc=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.boe05k9li3.wasm"
    },
    {
      "hash": "sha256-Uwv9MKopjVSXf1JnrLavGRzM+/9OY1jGR6DYDlIsrFw=",
      "url": "_framework/Microsoft.VisualBasic.Core.957mncgo3j.wasm"
    },
    {
      "hash": "sha256-FRqtpGFz+UomX7LTSShdIhprUj28/Wt4BsVRjJKJCgo=",
      "url": "_framework/Microsoft.VisualBasic.lkj0j9821g.wasm"
    },
    {
      "hash": "sha256-QvwsNnGj9Be/fhJyebzCipNSHRpWcXMSE3PX/5WqIpM=",
      "url": "_framework/Microsoft.Win32.Primitives.6ucriqtn57.wasm"
    },
    {
      "hash": "sha256-rHYeUTZYAEGFjVhEDGMEDADAsfLuiu+KSwL91QFXwvk=",
      "url": "_framework/Microsoft.Win32.Registry.4cq0sy6pju.wasm"
    },
    {
      "hash": "sha256-UbH2PV3qDwRKgvU/+awOYB8YXE4hCRyAeOuYGQC3bM0=",
      "url": "_framework/MudBlazor.1kk5654a9w.wasm"
    },
    {
      "hash": "sha256-zMcNgQ8+P/83tYmYHrJmP/Icbh7NStIlFomv6hSIVgg=",
      "url": "_framework/System.AppContext.wjggkrjcdz.wasm"
    },
    {
      "hash": "sha256-nlGZIYP0KN86aTqz3jU7R34pUNrTna6YgTcrRWT5iKI=",
      "url": "_framework/System.Buffers.qxif0lplfr.wasm"
    },
    {
      "hash": "sha256-qMJOHr40U1GoFpWAwoxmQYB5nx6Bf444V23csZKS/oQ=",
      "url": "_framework/System.Collections.Concurrent.41bm8l2nrh.wasm"
    },
    {
      "hash": "sha256-X/vhmDx7MBcgicMPzq9u5P3V5RmHPXR7lFdqZWNBtYM=",
      "url": "_framework/System.Collections.Immutable.7yd7h2opyh.wasm"
    },
    {
      "hash": "sha256-oIbDlARy+bHrWkVHIz1ULjkA5+cliXXJ5PLq7NwGHI0=",
      "url": "_framework/System.Collections.NonGeneric.s1mfw7otck.wasm"
    },
    {
      "hash": "sha256-aGuaIlYHzrSL0YUGwE/Khfp+wj/su9jBxfyT7ZRwvMM=",
      "url": "_framework/System.Collections.Specialized.g63mndhow6.wasm"
    },
    {
      "hash": "sha256-e7aak6RnybBtc27V8/+TrdGvw9ImB6Gx+fpL22QRyZs=",
      "url": "_framework/System.Collections.rkpgtdwhpo.wasm"
    },
    {
      "hash": "sha256-GvFrbJhQfVP3cFZoBVRiF77SpNaYc0Z7dT7xhj1c8Po=",
      "url": "_framework/System.ComponentModel.2xceumucs1.wasm"
    },
    {
      "hash": "sha256-D817nCbqp77xukDDbs18WRBSr8MLUuSS2R7U0t/F1/U=",
      "url": "_framework/System.ComponentModel.Annotations.9m91oxpmja.wasm"
    },
    {
      "hash": "sha256-wo3g/VUwzRZecr8JVZtGEBh8LPagYkU6ybGpLSPjWGw=",
      "url": "_framework/System.ComponentModel.DataAnnotations.ux4fjhznj0.wasm"
    },
    {
      "hash": "sha256-QVHbSMFi0rWSOKhSbA77syzIiEaQ6F1ie1sjuLQK/YQ=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.b5o28wkg4f.wasm"
    },
    {
      "hash": "sha256-OdnH3JYAXc1142mC743dFM/zXqvf45bjtoTKy7YgaVk=",
      "url": "_framework/System.ComponentModel.Primitives.1629qnt680.wasm"
    },
    {
      "hash": "sha256-INXYpV7nZj9D4/V+TDKvv6o64ttEZnbHNW5D0/8ejpk=",
      "url": "_framework/System.ComponentModel.TypeConverter.476rhnh44o.wasm"
    },
    {
      "hash": "sha256-OQaKD7ooTclAG4HGBBrCnljaA/RWL6Xv3BDUg/EvJkg=",
      "url": "_framework/System.Configuration.djc30hkqra.wasm"
    },
    {
      "hash": "sha256-N/mdScXJGAnIRa4qHN5TezRMmWMdd6W/ZJn2WKkx30Q=",
      "url": "_framework/System.Console.9o6w9dqubj.wasm"
    },
    {
      "hash": "sha256-fETgT4wpXW4vGltMdErbg8YmESDGXPzRwa+d7p3jHOM=",
      "url": "_framework/System.Core.897zprnzef.wasm"
    },
    {
      "hash": "sha256-OLkIwaonUtnIOH0ys4Y5NV1xADWFUDo56Qz/cMid6Jc=",
      "url": "_framework/System.Data.Common.0qycsssroq.wasm"
    },
    {
      "hash": "sha256-E3rO/leZuZkdnnaT8HQgNF2Bk6nKbA76oVrEtM2GRAM=",
      "url": "_framework/System.Data.DataSetExtensions.n74z2m2kxz.wasm"
    },
    {
      "hash": "sha256-aeTeUX1XBFuEErBSyokYOA2LWQrgfuG6mY3a9jxTmgo=",
      "url": "_framework/System.Data.fy0beduhai.wasm"
    },
    {
      "hash": "sha256-xVJ7LBou5gQU+c1lU2Fzd3WgxHnyPWcVgXsQ4Z03EBk=",
      "url": "_framework/System.Diagnostics.Contracts.1pkc3bfujc.wasm"
    },
    {
      "hash": "sha256-0CDqB9LlkrsTZtqx53vkhBufAaGeSNB1sula+AylqnI=",
      "url": "_framework/System.Diagnostics.Debug.oyvc877kn7.wasm"
    },
    {
      "hash": "sha256-Vahd43N9DqkLga53p53WEdHNou3Wn530uVtMEVRsG/s=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.tijidut9b5.wasm"
    },
    {
      "hash": "sha256-wvCawVNhCf+WbmyLxnLjG3Hfp8a8ug+QVCWoM6erdto=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.ukp3ff2hiw.wasm"
    },
    {
      "hash": "sha256-SynDG5R3WFuPN5mZN7ofG89eYCLFxhYEwsm1iI6Zkv8=",
      "url": "_framework/System.Diagnostics.Process.1l8xt8pltq.wasm"
    },
    {
      "hash": "sha256-WbfyZVApqnBitGJSGKo5lIAHlOxaYfIYhOJDq1qYgTo=",
      "url": "_framework/System.Diagnostics.StackTrace.9k4psq1man.wasm"
    },
    {
      "hash": "sha256-w40ZVUq2eQpJ0IuJSM7mKoK0EfsVSVrBbjSSq6f1eZg=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.3s5u54qrhw.wasm"
    },
    {
      "hash": "sha256-0pAVbXc1C5pCgVYXnD9W7OW7hky1bZX3Ye/NpyFqiEM=",
      "url": "_framework/System.Diagnostics.Tools.qinbl8f86p.wasm"
    },
    {
      "hash": "sha256-0Qh+b5F7HICyjzdJ3TOlTieJhDub7GCFzQIA40SCRd8=",
      "url": "_framework/System.Diagnostics.TraceSource.vc60zxnx9i.wasm"
    },
    {
      "hash": "sha256-it3TLKkpLV32P6MGAI1pmDd2oM+9EHxYll93h+X+TOk=",
      "url": "_framework/System.Diagnostics.Tracing.qjfvqe7ovi.wasm"
    },
    {
      "hash": "sha256-1jxtDVTOprjn2TuOroV61AkikemOVE9eHq1TXYIddaM=",
      "url": "_framework/System.Drawing.Primitives.i6c60479yi.wasm"
    },
    {
      "hash": "sha256-0KjwxAV0pLI8nfC01ZcvBnMcXe0kEwF4TWt9z7Q+yZ4=",
      "url": "_framework/System.Drawing.oewb08hsw5.wasm"
    },
    {
      "hash": "sha256-tuC9YS7UUrK6YFzGq3lfmnI98HLEhaKhSkWsXl7WyVo=",
      "url": "_framework/System.Dynamic.Runtime.ur648jn21s.wasm"
    },
    {
      "hash": "sha256-5DhfGFcY4MHmHLIvhK9zGTBoltF4yPHK1WLfaLvdzHM=",
      "url": "_framework/System.Formats.Asn1.4euhz40qm4.wasm"
    },
    {
      "hash": "sha256-pBse2VDd1UrV3cAB6zrrao3Q89Jr8usJw9yL+uBFZuE=",
      "url": "_framework/System.Formats.Tar.gffl7n4xwu.wasm"
    },
    {
      "hash": "sha256-o88XbOEDmWoEmsbXj1Wj6IP8Bb7ensgnb651J2qd5i8=",
      "url": "_framework/System.Globalization.Calendars.nfvmrjid1g.wasm"
    },
    {
      "hash": "sha256-qvsI7k60o7IlFjtmpl6CY5l7cy1h6wJG/T7zDVHGO6E=",
      "url": "_framework/System.Globalization.Extensions.yqqlhs6e65.wasm"
    },
    {
      "hash": "sha256-VtRXtJhbkuJ45UbjWL61zmaHQ0aLxxxb/LTKb+1BcaA=",
      "url": "_framework/System.Globalization.y114y1fsu5.wasm"
    },
    {
      "hash": "sha256-nT1lCOo31orN2lrEFLrERVPh8DdUrKfZHRVFIfkV330=",
      "url": "_framework/System.IO.Compression.Brotli.77m4tf6lnl.wasm"
    },
    {
      "hash": "sha256-Sj6VeIEB/wVnwytAk/H6UbLY0jgWx34xXhWeKNI3cA4=",
      "url": "_framework/System.IO.Compression.FileSystem.yef1ak2k8b.wasm"
    },
    {
      "hash": "sha256-xCZ1m8Sr4q2ZNghi7X/OReGL2c7pwaKqxhyk72C7Vbw=",
      "url": "_framework/System.IO.Compression.ZipFile.sgegssqou3.wasm"
    },
    {
      "hash": "sha256-cnN2nsXbxyBVOpa4knD1g2FUvdRqG/Qeba10ClA4QKY=",
      "url": "_framework/System.IO.Compression.mzfyiz7fl6.wasm"
    },
    {
      "hash": "sha256-/oRmkx1GOf+oElmdWe8Nqf20B8m+VbUcmaDsfgoTOhs=",
      "url": "_framework/System.IO.FileSystem.AccessControl.q2e3lvcd97.wasm"
    },
    {
      "hash": "sha256-taXGI3VuRyTDjAJwO1+MHVktmdxvcV9cY7t3pb8vfyo=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.fzl46jehhr.wasm"
    },
    {
      "hash": "sha256-4aEvjLOBtfXbwUqYYtQHyyUbF3iRUe7MIR5ZvUEE9zo=",
      "url": "_framework/System.IO.FileSystem.Primitives.bluloecgku.wasm"
    },
    {
      "hash": "sha256-NTXsgoHfQSy+kr+kcd+yDNcRMjOUi2GlO3pO2JORgvI=",
      "url": "_framework/System.IO.FileSystem.Watcher.3q240xoxyg.wasm"
    },
    {
      "hash": "sha256-eZSJjAvNPXb5CBFVTCCGphFqQedcncruk2K9YZg41ak=",
      "url": "_framework/System.IO.FileSystem.nkmts6qdzc.wasm"
    },
    {
      "hash": "sha256-oKq2TfOKdjY7/aVcIblIWw4PsGEOZW5Tl9LxwhMKVik=",
      "url": "_framework/System.IO.IsolatedStorage.g44r170pnd.wasm"
    },
    {
      "hash": "sha256-nicptZC42t3/0n6enYUjrOqvLZOtB6qU1WTPxxFTK/o=",
      "url": "_framework/System.IO.MemoryMappedFiles.u9kz3t57ly.wasm"
    },
    {
      "hash": "sha256-EWD+gUtlhBxOlV+VGmJdjMeXyknAfPHuEEIf7Mo12yQ=",
      "url": "_framework/System.IO.Pipelines.18jbya60ef.wasm"
    },
    {
      "hash": "sha256-LipXtmHW9X8ZASmIYiBQcrAK/bwG4VYfTICk9WnzXV4=",
      "url": "_framework/System.IO.Pipes.AccessControl.uceqrd9akn.wasm"
    },
    {
      "hash": "sha256-NJ7sD5e0Mtn8HumK/oOymWUomi2Et/E2yxd41CHq4lI=",
      "url": "_framework/System.IO.Pipes.gvu2poo3dw.wasm"
    },
    {
      "hash": "sha256-RgZm5Z1SNIUTD/U8/s0Acsl752xHG3o0hCBA1xFrKJc=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.msgphx5z3o.wasm"
    },
    {
      "hash": "sha256-z/35hjg+yE+artsNknqmy5NLEfPRJObcox7MEy1mIHQ=",
      "url": "_framework/System.IO.h4llw12btc.wasm"
    },
    {
      "hash": "sha256-pu/PlynRZDprtPrNEuay/XhrC/5wx/B6vNVums/CFgk=",
      "url": "_framework/System.Linq.Expressions.uigc577oxj.wasm"
    },
    {
      "hash": "sha256-KwZqZlpCZkIorzNWdmOzRZ1B1fUR96Sbs2Waf5d3Qy0=",
      "url": "_framework/System.Linq.Parallel.3q8cjvcv28.wasm"
    },
    {
      "hash": "sha256-w3p/ySYaR1OczHmqPDQ+PetGZJn0p9YCgKyz0gQj8f4=",
      "url": "_framework/System.Linq.Queryable.hrmgegy2no.wasm"
    },
    {
      "hash": "sha256-HgXlCpN1UVzJBRZQ/Z8XmGrvQyJ2jsq3SJ6/l9zGdP8=",
      "url": "_framework/System.Linq.ygwqgp8t2z.wasm"
    },
    {
      "hash": "sha256-tCfRy2BYXT+SFJq5uhIvDMqf0YrHZ/l5N1lFhHLAHLQ=",
      "url": "_framework/System.Memory.oxl1b6fsf1.wasm"
    },
    {
      "hash": "sha256-PLd6Nw38sfbgOf2iSEXBE1KnS4ZpdMPqcmO2HkUnez4=",
      "url": "_framework/System.Net.Http.Json.sa48txmfog.wasm"
    },
    {
      "hash": "sha256-CQCQPgXfJXvpH0LqIPQgfJBHtpWSyuiDIUeuHIjywVw=",
      "url": "_framework/System.Net.Http.n4pr0ic08w.wasm"
    },
    {
      "hash": "sha256-1vTN+kFEfqNd0yRMAR9Tymmygh9nNp8PYXRk8BXGNh8=",
      "url": "_framework/System.Net.HttpListener.ihqbimnfeg.wasm"
    },
    {
      "hash": "sha256-AQR5z7daKMY0FOJ83s6QokYHuJcvb1eLSfCvw+yr344=",
      "url": "_framework/System.Net.Mail.tlnu5zqcwn.wasm"
    },
    {
      "hash": "sha256-qUuAIt4/pZNnBtWcPm+bLsmCRuL9odU0QIrjwwd3zF8=",
      "url": "_framework/System.Net.NameResolution.hi9adgtnl0.wasm"
    },
    {
      "hash": "sha256-jHaIKTaLTlBmGcBcGFjDq4+CJJhQaBfpmnNZ/nJFlpc=",
      "url": "_framework/System.Net.NetworkInformation.0r8h86xh8h.wasm"
    },
    {
      "hash": "sha256-Z13Kn+1nIVCwq3bMsrHR2PW4C5Wjd7DbPcbGBzX60ds=",
      "url": "_framework/System.Net.Ping.9kwjfmvg2x.wasm"
    },
    {
      "hash": "sha256-/+tx4na8RqvReCMZb/mEkAD7+A1LfJwTP0W1TH8r7Pc=",
      "url": "_framework/System.Net.Primitives.lftwbzixfp.wasm"
    },
    {
      "hash": "sha256-68WZHPSFPhA1rvcm+lp1XFV6t0obwWxm2aFXdzR+798=",
      "url": "_framework/System.Net.Quic.z6z35bscxs.wasm"
    },
    {
      "hash": "sha256-1IzNw6MLbaJ6LWziy6pfhWWF58Fxo0gvLt3D50HTwJ4=",
      "url": "_framework/System.Net.Requests.8v7s6oprzp.wasm"
    },
    {
      "hash": "sha256-8PN5OwxT005xZGsEjHsfUz4SxKkj6u1UIdMT3p4xU/o=",
      "url": "_framework/System.Net.Security.k3nwbrkdjk.wasm"
    },
    {
      "hash": "sha256-SWNgHsCfG5Q52MoNBkVBYKI7DWJYwdT6LeoDbQOFciE=",
      "url": "_framework/System.Net.ServicePoint.tnbxmhn2d7.wasm"
    },
    {
      "hash": "sha256-tvLbV6cSyXmuKEqa7RLwx2EtpP9YaN7MnmiLipXVP7k=",
      "url": "_framework/System.Net.Sockets.6pc0l2xxlq.wasm"
    },
    {
      "hash": "sha256-UDWzmdxTUb6pSsYt7rlGxvjXLXx78IE0EYh4lRXf5nY=",
      "url": "_framework/System.Net.WebClient.kznhbzqxk0.wasm"
    },
    {
      "hash": "sha256-Ut8tnMkGKAvLwiQRCV7qmVehxw4FH9u9sqS190vzblk=",
      "url": "_framework/System.Net.WebHeaderCollection.u0p0mzmszr.wasm"
    },
    {
      "hash": "sha256-nNcB4UW9fV+yBdQlH4yw5sIC1WC49LTDLK6Lsop9Xqk=",
      "url": "_framework/System.Net.WebProxy.ksyxevxlhe.wasm"
    },
    {
      "hash": "sha256-5DOzd1M4IOU2+sMlbHLnFZ3sjULwS4q6bL9P92niED0=",
      "url": "_framework/System.Net.WebSockets.Client.k0h375mn5s.wasm"
    },
    {
      "hash": "sha256-ych99vBLrBvr3CAmRih9yfdeJ0BH+688QlOxXvdpyS0=",
      "url": "_framework/System.Net.WebSockets.v6w1ivf3ds.wasm"
    },
    {
      "hash": "sha256-nH29brf75v8S00SjOEI3ypjrgacD6k6wU9Sqkucfq/U=",
      "url": "_framework/System.Net.wnoz25yi7h.wasm"
    },
    {
      "hash": "sha256-TMhhJrlqofG/O/aXBEvp8k6wdJm7S80ldPtziEhJNVE=",
      "url": "_framework/System.Numerics.83sequ6v25.wasm"
    },
    {
      "hash": "sha256-1fS0YmByeOlLfX3STxvkUKB/5F7adv1QLlrErcFsmpA=",
      "url": "_framework/System.Numerics.Vectors.54kc4g87bl.wasm"
    },
    {
      "hash": "sha256-WvjmUZB1Lg9angYIxYs1zfQHNKDEISuETtetNdsrB9c=",
      "url": "_framework/System.ObjectModel.q0cap5ndy9.wasm"
    },
    {
      "hash": "sha256-ZuABTuOsWzbHjPsWEIQg/MtFhyIaPzKJSZlhbqbsaY4=",
      "url": "_framework/System.Private.CoreLib.260f1koe4w.wasm"
    },
    {
      "hash": "sha256-7ZKVF4DEfoKM55KFqqmj5myllp6c2kjaQ7WIYhrbruI=",
      "url": "_framework/System.Private.DataContractSerialization.v5gh10i5yb.wasm"
    },
    {
      "hash": "sha256-4KZ8i7HuoQ8U30wOBzBhghppM2+tIpBj4qsOZRdDrps=",
      "url": "_framework/System.Private.Uri.43bb65mlzv.wasm"
    },
    {
      "hash": "sha256-DJDqNhjDhSpWeImjQBIFWIzQ4zBEQPlMl/4nU0fdM+U=",
      "url": "_framework/System.Private.Xml.Linq.0f3fhgekik.wasm"
    },
    {
      "hash": "sha256-FAfhgKHXCRbgeuMF1ZMtP+FeaOlynZs4D4QTDplWaVk=",
      "url": "_framework/System.Private.Xml.g3f6fekng4.wasm"
    },
    {
      "hash": "sha256-wO20gE2iqEjkF4Eok10E7j9MP68ceAIEYm57LaE/P0I=",
      "url": "_framework/System.Reflection.0oqtydjwuw.wasm"
    },
    {
      "hash": "sha256-UH1sIOMqYq1WcYDlHlT6UDOQ0uHjfqzDeKofeIYjJzI=",
      "url": "_framework/System.Reflection.DispatchProxy.kjxqpq7ien.wasm"
    },
    {
      "hash": "sha256-6PWfzyekGs6bqPLJjzcoSgjBPDouQb1ptd9u9X3V4Os=",
      "url": "_framework/System.Reflection.Emit.8o7h1ya3fc.wasm"
    },
    {
      "hash": "sha256-CpVhniC2aJwh8QwaePjwBT6hotT5Q9Ikur31PGAhkVo=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.6dvtpyd0eg.wasm"
    },
    {
      "hash": "sha256-2E+I2+eFq4nAPthQRHT6Zm/VHLU6tDEIv8hVgFy8+ak=",
      "url": "_framework/System.Reflection.Emit.Lightweight.wikhmey5vn.wasm"
    },
    {
      "hash": "sha256-s6fwyuuHefkUFx/SXIRJvIcCQmwcCTDpVANTiT/2dUw=",
      "url": "_framework/System.Reflection.Extensions.30vnjmebvk.wasm"
    },
    {
      "hash": "sha256-BxunKAg8NLKcSgJMGY18BkVKwf7CjLiYU6xNm8jB/Nk=",
      "url": "_framework/System.Reflection.Metadata.5xd6l5rhot.wasm"
    },
    {
      "hash": "sha256-gdcjyZonc7NOgzFlZJor8rMglWi3IzEUvCkcLdlctWM=",
      "url": "_framework/System.Reflection.Primitives.tlnoiibva3.wasm"
    },
    {
      "hash": "sha256-9lFU6wRYUPeDkoFETYIK/7u3GsNr88UUiGl5wcAAzak=",
      "url": "_framework/System.Reflection.TypeExtensions.e39g4q7yfi.wasm"
    },
    {
      "hash": "sha256-XCst5MGtjNWcFvHkk+zrUEhIISi1h2psaNJHcO7Cmgs=",
      "url": "_framework/System.Resources.Reader.wpo2zev0s7.wasm"
    },
    {
      "hash": "sha256-Jq+JHo/pbE6QGOXDaR/UFIyGPs0gcxxCuHRKA+VntTk=",
      "url": "_framework/System.Resources.ResourceManager.yu0mbe8dqz.wasm"
    },
    {
      "hash": "sha256-AhM8rMLPCY2ES400tiRNfA7JhW8ixboKjnkcBVkHEaQ=",
      "url": "_framework/System.Resources.Writer.ax5ketfhqn.wasm"
    },
    {
      "hash": "sha256-Ren/2MQ7590BSsmHJaONnJGalW5bSPxrvhOluKTLKyE=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.t22r2hga5s.wasm"
    },
    {
      "hash": "sha256-61u0aWgG5uyNF7I9qwcd7XX3tPAjHOm3F+F2oImN1sU=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.htbdnk2fwv.wasm"
    },
    {
      "hash": "sha256-86R4BSvZ1lWXldNn/2OrQJIWq0/JuLJcNoBZW5N5bjA=",
      "url": "_framework/System.Runtime.Extensions.d0cxom7gd5.wasm"
    },
    {
      "hash": "sha256-wQ/dwsAmK5WggYy0JAGQ/IC0lloxA4gw07NASV5qIdA=",
      "url": "_framework/System.Runtime.Handles.b5k5zmuwgi.wasm"
    },
    {
      "hash": "sha256-XYo3wtLSDhTn/fUoR+128erS9t5rXyfmbnBC8sxCzi8=",
      "url": "_framework/System.Runtime.InteropServices.3wys6wp0hf.wasm"
    },
    {
      "hash": "sha256-9Bo+3vcBp4y38940m0OkQ7KXsEtlhhZB6peyUK3OWww=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.81mu2ue34e.wasm"
    },
    {
      "hash": "sha256-H/+oCdfBmzXO7BF/teuSmCI3vBy3F4h3m58c6tLUQXk=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.9e23ikzqtx.wasm"
    },
    {
      "hash": "sha256-Gq40iDS+rc6Xu7WEIf/gUu4vai4+ry2Qk4mZWt/w2jE=",
      "url": "_framework/System.Runtime.Intrinsics.21w35a47uk.wasm"
    },
    {
      "hash": "sha256-vYEpQOFXFkFcykCavSkqTJTQ7Zov3fbzeKkriBRs0qA=",
      "url": "_framework/System.Runtime.Loader.hrynaujjkm.wasm"
    },
    {
      "hash": "sha256-8PlMzNcgRS5mJMHfm4m4phPm+scgsqZM/OaLI1FVTxQ=",
      "url": "_framework/System.Runtime.Numerics.0c83dwcdvn.wasm"
    },
    {
      "hash": "sha256-fUkL8Dufj+gbBQGOvTyX19Z+zioG/26JCikYNhbVnqQ=",
      "url": "_framework/System.Runtime.Serialization.Formatters.dgbmidssny.wasm"
    },
    {
      "hash": "sha256-PLB5uuWF2ueRzRXqws7I6n/uDCZYAAYJroS1qdzThwQ=",
      "url": "_framework/System.Runtime.Serialization.Json.w10iz70c7r.wasm"
    },
    {
      "hash": "sha256-OlxV9CwTx/Zc42zUfhXeXE9r6BMzt6AFwzep7WBwQLU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.q80wbiuhbh.wasm"
    },
    {
      "hash": "sha256-lyl3BzWoY/wZMKOmpSZML/k+yLvzgp/ZkD4eJh7mvVI=",
      "url": "_framework/System.Runtime.Serialization.Xml.rn87ik2vwy.wasm"
    },
    {
      "hash": "sha256-cNmuKhjxFMLjpo+lLe3u47bymdTWVAj7WJ9lSE2tYnM=",
      "url": "_framework/System.Runtime.Serialization.sd6dtmz198.wasm"
    },
    {
      "hash": "sha256-dFJMID9tW28pkSEGE2ceDd481KbRwG04JWbOmGOi/bo=",
      "url": "_framework/System.Runtime.seazzwnxxn.wasm"
    },
    {
      "hash": "sha256-Kv9HhBKSUQ3xZLPnUBdqeU7c1qIG6e3fXZD9BKh6WZs=",
      "url": "_framework/System.Security.AccessControl.m4fpsja2rc.wasm"
    },
    {
      "hash": "sha256-uj1x+0x8FNmVa881Zt+EKfxLMw9OpiGnPcxdqFe9fCM=",
      "url": "_framework/System.Security.Claims.ytx4627b2d.wasm"
    },
    {
      "hash": "sha256-AtNI6HL708zvhaE0MHgIWQ4r7dFZcDsqcpmKUR4jIZs=",
      "url": "_framework/System.Security.Cryptography.Algorithms.mao4tvgvcr.wasm"
    },
    {
      "hash": "sha256-3+rCETLypXoi+Rto4wub5Li2uSBh8M+nNOGRlIcdSuU=",
      "url": "_framework/System.Security.Cryptography.Cng.rdrl1vzzug.wasm"
    },
    {
      "hash": "sha256-FWJegxxeQNIQ9Qr5ATgBT/8nqJK4F/gdel1W738OijE=",
      "url": "_framework/System.Security.Cryptography.Csp.9r4wa2nmiz.wasm"
    },
    {
      "hash": "sha256-DwhDhvxgl+Xu2I2YujLhyZ+sPXuc/IeeIyk/qVnvNMY=",
      "url": "_framework/System.Security.Cryptography.Encoding.5zst8q1gn3.wasm"
    },
    {
      "hash": "sha256-UQTd5DGRojU9fI51VCyHXuWOYa8acBwANLdNp58mBRA=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.5z25m0dz7u.wasm"
    },
    {
      "hash": "sha256-m9kQErl4sWtJLfl7TE+s84tvxFViQ/9eui8JwQKwqHo=",
      "url": "_framework/System.Security.Cryptography.Primitives.fj6aurjtax.wasm"
    },
    {
      "hash": "sha256-puAn0cgkPtedarU9QIttr8TFbyB1Tllfn8GoD8ZHClQ=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.a058wx18eg.wasm"
    },
    {
      "hash": "sha256-OqYZ2UdjPNxtV5uCko1EqhpyXg0D71Ll/PLwMDkHebQ=",
      "url": "_framework/System.Security.Cryptography.ezciksx480.wasm"
    },
    {
      "hash": "sha256-+DrqiuVMSODUE/CzqUmjxO5yANBLz7cznTbrfTegBGU=",
      "url": "_framework/System.Security.Principal.Windows.s7vw7ynn3v.wasm"
    },
    {
      "hash": "sha256-WsXpxjsuK6pWC+A/PKr8sVjN8xKS/xXKMF/CMWC6ga4=",
      "url": "_framework/System.Security.Principal.ie5wisqcha.wasm"
    },
    {
      "hash": "sha256-VMILQS2qiULInYpdvW2AHgo+y4tfsetfQZTdP50iXFY=",
      "url": "_framework/System.Security.SecureString.4entykrdjg.wasm"
    },
    {
      "hash": "sha256-ilU8DQvYTBqYimJanJtQ4SKvRf9/4mBbNR/2cBQLHsI=",
      "url": "_framework/System.Security.ydosgotks6.wasm"
    },
    {
      "hash": "sha256-0D0KpINvvyb+XlJyC0kPYbgNrD4nCVz0dk0kZcl1SU0=",
      "url": "_framework/System.ServiceModel.Web.o6gl91ft64.wasm"
    },
    {
      "hash": "sha256-eiycKVKNkD7sOwglFJozLbdcbPLcPrq0cW1OLGwb1CI=",
      "url": "_framework/System.ServiceProcess.q77s0wcagq.wasm"
    },
    {
      "hash": "sha256-mU9Cwm6Fr040HMe0izRK+t71yDHTguw5os5KjwOnY0g=",
      "url": "_framework/System.Text.Encoding.CodePages.hm3tkp0ck1.wasm"
    },
    {
      "hash": "sha256-l+Daq9oy31pNnbzB5FebSo14ufzZOLapb+oYh55NsGg=",
      "url": "_framework/System.Text.Encoding.Extensions.395gaqjhiy.wasm"
    },
    {
      "hash": "sha256-Wq8DHfsczg6KLfxEEOIxvaAnGWyG73a/Iribk+iWBwE=",
      "url": "_framework/System.Text.Encoding.i1bjmvmm07.wasm"
    },
    {
      "hash": "sha256-+uha2pwve6oF+GwfwNOcQzMgwJnYuFUPWIKabLukJ/4=",
      "url": "_framework/System.Text.Encodings.Web.ac40b6xgwv.wasm"
    },
    {
      "hash": "sha256-iyEvLp4ykjYJVJurWpV+qzUtMZBWwAlv1FMPpjRNQ7c=",
      "url": "_framework/System.Text.Json.jijvh3dhv0.wasm"
    },
    {
      "hash": "sha256-B4ZbPPshPqWg+bHQnBZMtIxHCM3bBTVzxLF8BxLkThA=",
      "url": "_framework/System.Text.RegularExpressions.dzgstuohqp.wasm"
    },
    {
      "hash": "sha256-OKiXYqyARjCi1xLvrf0qJ/vPwf7nMdlXmYiyKced1RE=",
      "url": "_framework/System.Threading.Channels.g23d3hgpw6.wasm"
    },
    {
      "hash": "sha256-OdweWxcbc4g5aJet4ZtnIfE0v1/XwFPNc9AO7fzLjdQ=",
      "url": "_framework/System.Threading.Overlapped.lp65npv3qf.wasm"
    },
    {
      "hash": "sha256-TGrsnnY6MzG5JKLv7Cxn7V1PGHaZEWdRhB+GWpW5uHk=",
      "url": "_framework/System.Threading.Tasks.Dataflow.w17gi3pt50.wasm"
    },
    {
      "hash": "sha256-qy0tWaXjOR/8zeD1iYbIwJVzp3XHRXMGhzFLZjifKlM=",
      "url": "_framework/System.Threading.Tasks.Extensions.tyb3j0gex4.wasm"
    },
    {
      "hash": "sha256-F7ywOa74VeAamIBsWs49kzE+2evhqnYjzyFmiEEW8l4=",
      "url": "_framework/System.Threading.Tasks.Parallel.7k4446bfsg.wasm"
    },
    {
      "hash": "sha256-NIfbbUegjOkivG5T8hNzGAWF4ad/WkcjA3vOJ4/ZO2o=",
      "url": "_framework/System.Threading.Tasks.gtp6rlhd26.wasm"
    },
    {
      "hash": "sha256-gCgFaUN5TBnLdQQtl0jP0833s+hUG5sPdhJEn6hIsKc=",
      "url": "_framework/System.Threading.Thread.knnvqtuav1.wasm"
    },
    {
      "hash": "sha256-dfMAInXh2CIfUgWIAVBL/vJRGvBSMxOUW194F/8W8KY=",
      "url": "_framework/System.Threading.ThreadPool.9riudzas8v.wasm"
    },
    {
      "hash": "sha256-zEACMLRZljxvxVWNk6g2gf0sS3++y/RQVZYzLx23dZY=",
      "url": "_framework/System.Threading.Timer.89cvho2jcc.wasm"
    },
    {
      "hash": "sha256-VoeEh55uX2m0ZktCq4RUxwHNah0ZF92iPcEkUoEum5g=",
      "url": "_framework/System.Threading.q8fqtn7lcv.wasm"
    },
    {
      "hash": "sha256-YJ38GR234yRSGonDR3gTBj4jiZHuler7NYXzalKLm7o=",
      "url": "_framework/System.Transactions.4z3xjuivqz.wasm"
    },
    {
      "hash": "sha256-OcddnS6k3oIHXY0fEigktNEXJpcK1BCxsNBKqk13anY=",
      "url": "_framework/System.Transactions.Local.djcztcb8az.wasm"
    },
    {
      "hash": "sha256-UDi9tZioTLXOyylmGQ/V605sCr4FEo+8c6rWIJqqAAI=",
      "url": "_framework/System.ValueTuple.8a4c7wg91c.wasm"
    },
    {
      "hash": "sha256-npxozDwSmTSf/iM2q8N3pw+1pk78ng8mBeT3vUdqAFY=",
      "url": "_framework/System.Web.24p1q9pe46.wasm"
    },
    {
      "hash": "sha256-uctcnfZXIHFbR5WJrm6Bo0rKWbg9NqxsNEu87p/MEU0=",
      "url": "_framework/System.Web.HttpUtility.l1o886gzm0.wasm"
    },
    {
      "hash": "sha256-fHMvzLp88fmZmBp9U8/UfAAKZoRfGxgf8iRF+XGe3yo=",
      "url": "_framework/System.Windows.4c525wyp64.wasm"
    },
    {
      "hash": "sha256-2omv3hQTZNNL3E5u9iJU+tEe7WJASAHGcO7jyRN+too=",
      "url": "_framework/System.Xml.Linq.yu4d43kaof.wasm"
    },
    {
      "hash": "sha256-RVL8e7drjyFOQ7cdzUhXKMkiJ7VLMDqsQssd5moLYYo=",
      "url": "_framework/System.Xml.ReaderWriter.5cdzkkcght.wasm"
    },
    {
      "hash": "sha256-WDtf9ZsamNAfzGNON25//OlW5nknpUHgP/BUTndWj+0=",
      "url": "_framework/System.Xml.Serialization.o4f3scoc36.wasm"
    },
    {
      "hash": "sha256-v3KxsR2yGhpFpyb1GKqKqCm5ZNjb2MGXxxU4eqg8bzE=",
      "url": "_framework/System.Xml.XDocument.fo5sjh906d.wasm"
    },
    {
      "hash": "sha256-/yzkZsy1a5iQVArKgKMcnrmzhqPtTL79Z0MadgKLH58=",
      "url": "_framework/System.Xml.XPath.XDocument.x8kikae7hn.wasm"
    },
    {
      "hash": "sha256-8ntOugsafI0qsz6o/qEScLPd6yzp/mFJgGzzwPZFtfY=",
      "url": "_framework/System.Xml.XPath.aa02a1mnrt.wasm"
    },
    {
      "hash": "sha256-4r/p0Z0yIihDG6ay6RUkySNi9Ez7+44WrU+s022BimY=",
      "url": "_framework/System.Xml.XmlDocument.ygk90k2g03.wasm"
    },
    {
      "hash": "sha256-7bgj+t8int0cXO1MB3bBYFJhK6+Eltx6xr3uwH+4cYw=",
      "url": "_framework/System.Xml.XmlSerializer.tw9r23aubo.wasm"
    },
    {
      "hash": "sha256-o53JrNl7CwdyHW5W05YH33r34ppyt8CgUBusWxdMsaw=",
      "url": "_framework/System.Xml.vpc5q975n9.wasm"
    },
    {
      "hash": "sha256-DKnufGddJFxY36OQssBgk65eeiOSW/KWOWZ0o8oUq0A=",
      "url": "_framework/System.g78iv8h41a.wasm"
    },
    {
      "hash": "sha256-K6fVEeTcUpmfAgcQZKEF2t2LTMJAi1RLO0DTUkOOPOk=",
      "url": "_framework/WindowsBase.lc9eiktle0.wasm"
    },
    {
      "hash": "sha256-BMpUBC4e0khVsAdibSsSlIrkJCpAuUkqKgxTA6JU2P8=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-xt8RyUsprzUajnIi0I3fe6oJHxQ60AIkMBKyIK6CLNE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ONpJkJu1uYz96ZP615rMF19wVzWwHXaWcLEhVlqose4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-cOUmeWyyghmWpRbFA5NUYAF7CsIp1SLDfi2BEfr4SaU=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-dDM8L8vSODqdWkZFTgHiiqLdNoQ3rSGH/kdJxHx42ys=",
      "url": "_framework/dotnet.native.0fbbyz7uv3.js"
    },
    {
      "hash": "sha256-tO2PYG8AfXSRpjgNufGEYXKxTomWJHfUBzNyNCgN0u0=",
      "url": "_framework/dotnet.native.csd2k7t6tf.wasm"
    },
    {
      "hash": "sha256-Nxi58ygfXerbT8jR1N/1rm08zEP+Doobp9HRXVfpS1M=",
      "url": "_framework/dotnet.runtime.h6izlfp54g.js"
    },
    {
      "hash": "sha256-2Xzz9vtvp+bBgOa+tpFZ5oV2hX3n0aLcNxb15THPgJA=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-aUFPl5WH/0Mzjw8aAubxdZSHJgNbwwmNuWE1iHwCEG4=",
      "url": "_framework/mscorlib.p8nn03wyo0.wasm"
    },
    {
      "hash": "sha256-0P7glxqKB0dgs2xIJ51l8/B9w6bkmInT6Kq0Lx5/Zjk=",
      "url": "_framework/netstandard.8iwlv2ubpa.wasm"
    },
    {
      "hash": "sha256-PlReFrx3e7g71Qu/Al7b3ozg9JnEz1StahSU9k6NRUM=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-OA05GcRCH1QlrxSgQvmw/ylO7EyjrLieF3Z7+vPxAyc=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7ieZghAMBTZNOZQm4cK05a3b54keIzxJI3FcQwZhfH8=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
